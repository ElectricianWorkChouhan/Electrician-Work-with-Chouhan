package com.chouhan.electricianwork

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.print.PrintAttributes
import android.print.PrintManager
import android.print.PrintDocumentAdapter
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.ValueCallback
import android.webkit.WebChromeClient.FileChooserParams
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var printWebView: WebView? = null
    private var filePathCallback: ValueCallback<Array<android.net.Uri>>? = null
    private val fileChooserRequest = 4102

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.setSupportZoom(false)
        webView.settings.builtInZoomControls = false
        webView.settings.displayZoomControls = false
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                filePath: ValueCallback<Array<android.net.Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = filePath
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/csv", "text/comma-separated-values", "application/vnd.ms-excel", "application/octet-stream"))
                }
                return try {
                    startActivityForResult(Intent.createChooser(intent, "CSV फ़ाइल चुनें"), fileChooserRequest)
                    true
                } catch (e: Exception) {
                    filePathCallback?.onReceiveValue(null)
                    filePathCallback = null
                    Toast.makeText(this@MainActivity, "फ़ाइल चयन नहीं खुला: ${e.message}", Toast.LENGTH_LONG).show()
                    false
                }
            }
        }
        webView.addJavascriptInterface(AppBridge(), "AndroidBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileChooserRequest) {
            val callback = filePathCallback
            filePathCallback = null
            val result = if (resultCode == Activity.RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            callback?.onReceiveValue(result)
        }
    }

    inner class AppBridge {
        @JavascriptInterface
        fun shareText(text: String) {
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "Electrician Work with Chouhan")
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                try {
                    startActivity(Intent.createChooser(send, "पूरी एंट्री शेयर करें / Share entries"))
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Share नहीं खुला: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun shareInstalledApk() {
            runOnUiThread {
                try {
                    val shareDir = File(cacheDir, "shared").apply { mkdirs() }
                    val apkFile = File(shareDir, "Electrician-Work-with-Chouhan.apk")
                    File(applicationInfo.sourceDir).copyTo(apkFile, overwrite = true)
                    val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", apkFile)
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "application/vnd.android.package-archive"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, "Electrician Work with Chouhan APK")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(send, "ऐप APK शेयर करें / Share app APK"))
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "APK शेयर नहीं हुई: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun saveCsv(csv: String, fileName: String) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                        put(MediaStore.Downloads.MIME_TYPE, "text/csv")
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("Download file नहीं बन पाई")
                    contentResolver.openOutputStream(uri)?.use { it.write(csv.toByteArray(Charsets.UTF_8)) }
                        ?: throw IllegalStateException("File में data नहीं लिखा जा सका")
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
                    FileOutputStream(File(dir, fileName)).use { it.write(csv.toByteArray(Charsets.UTF_8)) }
                }
                runOnUiThread { Toast.makeText(this@MainActivity, "CSV फ़ाइल Downloads में सेव हो गई।", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "CSV सेव नहीं हुई: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }

        @JavascriptInterface
        fun printHtml(html: String) {
            runOnUiThread {
                val reportView = WebView(this@MainActivity)
                printWebView = reportView // Keep the WebView alive until Android finishes preparing the print job.
                reportView.settings.javaScriptEnabled = false
                reportView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        try {
                            val printManager = getSystemService(PRINT_SERVICE) as PrintManager
                            val adapter: PrintDocumentAdapter = reportView.createPrintDocumentAdapter("Electrician-Work-Report")
                            printManager.print(
                                "Electrician Work Report",
                                adapter,
                                PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build()
                            )
                        } catch (e: Exception) {
                            Toast.makeText(this@MainActivity, "PDF/Print नहीं खुला: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
                reportView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
