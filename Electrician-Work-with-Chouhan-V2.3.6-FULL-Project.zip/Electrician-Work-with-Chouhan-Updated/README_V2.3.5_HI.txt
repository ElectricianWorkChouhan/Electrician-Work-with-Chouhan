V2.3.5 Full Android Project

Project folder: Electrician-Work-with-Chouhan-Updated
Package: com.chouhan.electricianwork
Version: 2.3.5 (versionCode 16)

Build on GitHub Actions: repository में ZIP upload करने के बाद आपके repository के root workflow को ZIP extract करके project की settings.gradle.kts वाली directory से assembleDebug चलाना चाहिए। इस ZIP में project के अंदर .github/workflows/build.yml भी है; GitHub तभी workflow चलाता है जब workflow repository के root .github/workflows/ में मौजूद हो।

Feature details and known PDF-import limitation: V2.3.5_RELEASE_NOTES_HI.txt
