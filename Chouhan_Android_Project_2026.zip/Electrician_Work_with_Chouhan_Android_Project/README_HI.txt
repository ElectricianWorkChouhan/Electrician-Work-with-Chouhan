Electrician Work with Chouhan — Android project

इस ZIP में Android ऐप का source project है। यह अभी compiled APK नहीं है।

APK बनाने के लिए:
1. कंप्यूटर में Android Studio इंस्टॉल करें।
2. Android Studio में इस ZIP को extract करके project folder खोलें।
3. Gradle sync पूरा होने दें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK app/build/outputs/apk/debug/ में मिलेगा।

ऐप की मुख्य जानकारी:
- हिंदी + English UI
- Premium dark, white + blue design
- Offline काम; entries डिवाइस के app storage में रहती हैं
- Add/Edit/Delete, search, month filter, total amount
- CSV export और PDF/Print

ध्यान दें:
- इस चैट के environment में Android SDK/Gradle build उपलब्ध नहीं है, इसलिए यहाँ से signed/installable APK compile नहीं किया गया।
- ऐप uninstall करने या app data clear करने से local entries हट सकती हैं। समय-समय पर CSV export करके backup रखें।
