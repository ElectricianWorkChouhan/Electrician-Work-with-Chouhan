Electrician Work with Chouhan – V2.3.7 Full Android Project

Project folder: Electrician-Work-with-Chouhan-Updated
Package: com.chouhan.electricianwork
Version: 2.3.7 (versionCode 18)

V2.3.7 is based on the supplied V2.3.6 project. No existing options or features are intentionally removed.

V2.3.7 change:
- Import PDF/CSV button added to the Electrician के साथ ledger section.
- The same Import button applies to the currently selected ledger: general Electrician के साथ or the individual ledger opened via Add Electrician.
- Import merges into the active ledger only; existing records and other ledgers are preserved. Duplicate matching is attempted.
- Existing Import PDF/CSV in Electrician – अपना हिसाब remains.
- Existing tap-based Share (Work Entries / Payments → PDF / CSV), separate electrician ledgers and confirmed X-delete remain unchanged.

CSV supports the app's exported Work Entries/Payments columns and legacy work/payment backup columns. PDF import requires selectable text and Internet to load PDF.js; scanned/image PDFs need OCR and are not supported.

Build: place the project folder in the repository and run the Android Gradle workflow. This ZIP has not been Gradle-built or device-tested in this environment.


V2.3.7 Customer Dashboard update (project source):
- Customer can add and view their own home Work Entries, with optional approved Electrician selection.
- Customer can add and view their own Payments.
- Approved Electrician directory is shown in Customer Dashboard.
- Customer Share menu offers Work Entries PDF/CSV and Payments PDF/CSV.
- Customer Import menu supports Work Entries and Payments from CSV or selectable-text PDF.
- Customer records use separate customerHomeEntries/customerPayments collections and do not enter the electrician's private ledger.
- Firestore Rules file updated for customer-owned records and approved electrician directory reads. Publish reviewed rules in Firebase Console before testing cloud writes/listing.
- PDF text extraction requires internet to load PDF.js; scanned/image PDFs need OCR and are not supported.
- Source update only; Android APK build/device test not performed here.
